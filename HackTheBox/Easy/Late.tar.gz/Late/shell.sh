#!/bin/bash
cat /home/svc_acc/.ssh/id_rsa
