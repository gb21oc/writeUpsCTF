#!/bin/bash
ls -la /home/svc_acc/.ssh
cd /home/svc_acc/.ssh
cat /home/svc_acc/.ssh/id_rsa
tac /home/svc_acc/.ssh/id_rsa
